The font images were rendered with the 11px version of the font binary at a font size of 11 and no antialiasing in Sublime Text (OS X).

The numerals in the font name indicate the 11px and 14px font sizes.
