Choose between alternates and adjust line-height + letter-spacing on [larsenwork.com/monoind](http://larsenwork.com/monoid/)
