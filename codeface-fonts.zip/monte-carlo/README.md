Gallery image was generated at font size 12 without antialiasing setting in Sublime Text
