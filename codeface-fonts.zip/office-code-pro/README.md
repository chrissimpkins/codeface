
OfficeCodePro-XXX.otf - slashed zeros

OfficeCodeProD-XXX.otf - dotted zeros