displayed at font size 12 without antialiasing in Sublime Text

ProggyClean.ttf - dotted zeros

ProggyCleanSZ.ttf - slashed zeros
