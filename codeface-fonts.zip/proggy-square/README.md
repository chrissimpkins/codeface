displayed at 16pt without antialiasing

ProggySquare.ttf - dotted zeros

ProggySquareSZ.ttf - slashed zeros