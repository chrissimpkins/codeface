displayed at 16pt without antialiasing

ProggyTiny.ttf - dotted zeros

ProggyTinySZ.ttf - slashed zeros